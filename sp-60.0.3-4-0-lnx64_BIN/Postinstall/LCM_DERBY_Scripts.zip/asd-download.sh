#!/bin/bash
#trap exit INT
trap exit 2 3 15
trap "" 1
################
#Copyright (C) 2009 ArcanaNetworks, Inc. No part of this file may be reproduced, stored in a retrieval system, or transmitted, in any form or by any means, electronic, mechanical, photocopying, recording or otherwise without the prior permission of the publisher.Any rights not expressly granted herein are reserved.
###############

export PATH="/opt/java/jre/bin:$PATH"

NTLMAPROXY=ntlmaproxy
NTLMA_PROXY=127.0.0.1
NTLMA_PORT=5865

SED=/bin/sed
DATE=`date`
GREP=/bin/grep
SORT=/bin/sort
CUT=/bin/cut
ECHO=/bin/echo
AWK=/bin/awk
BINDIR=/usr/bin
CURL=$BINDIR/curl
CAT=/bin/cat 
TAR=/bin/tar
RM=/bin/rm
DF=/bin/df
MD5SUM=/usr/bin/md5sum
TR=/usr/bin/tr
MASTERFILE=SNOOSC-RELINFO
PROXYINFO_FILE=/etc/scproxyinfo
CONFIGUREPROXY=$BINDIR/configureproxy
DATE=/bin/date
DU=/usr/bin/du
MV=/bin/mv
WGET=/usr/bin/wget

CERT=""
UPDATELOG=/opt/LCM/logs/install
TEE=/usr/bin/tee
PREFIX="ASD-DOWNLOAD"
AGENTPROP=/opt/cisco/ss/adminshell/properties/adminshell.properties

CODE_SUCCESS="2008"
CODE_NAUTH="2009"
CODE_NFOUND="2010"
CODE_REGISTER="2011"
CODE_DENIED="2012"
CODE_ERROR="2013"
ERROR_DOWNLOAD="2014"
UNRECO_ERROR="2015"
EXECP_ERROR="2016"
UNKNOWN_ERROR="2017"
CHECKSUM_ERROR="2018"
FILE_ERROR="2019"
REGISTERURL_ERROR="2020"
DBFILE_ERROR="2021"

#getting proxy information 
if [ -f $PROXYINFO_FILE ];then
	. $PROXYINFO_FILE
fi

if [ -n "$proxyname" ]
then
	CURLFLAGS="--proxy $proxyname:$proxyport "
fi

if [ -n "$proxyuser" ]
then
	PROXY_AUTH="--proxy-user $proxyuser:$proxypassword "
        CURLFLAGS="$CURLFLAGS $PROXY_AUTH "
else
         PROXY_AUTH="--proxy-user dummy:dummy"
         CURLFLAGS="$CURLFLAGS $PROXY_AUTH "	 
fi
	 
if [ "$socks" = "yes" ]	 
then	 
         CURLFLAGS="$CURLFLAGS --socks5 $proxyname:$proxyport"	

fi

CLEANUP()
{
	printf "\n$PREFIX: Removing temporary files...\n" >> $UPDATELOG
	$RM -rf temp_out1
	exit 0
}


# To perform curl GET /POST
#args  url outputfile data(if any)
perform_http()
{

	
	connUser=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/registerInfo;create=true;user=app;password=password';" "select GENERIC_USER_ID from REGISTER_INFO;")
	connUser="$(echo -e "${connUser}" | tr -d '[:space:]')"
    
	connPwdEnc=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/registerInfo;create=true;user=app;password=password';" "select GENERIC_PASSWORD from REGISTER_INFO;")
	connPwdEnc="$(echo -e "${connPwdEnc}" | tr -d '[:space:]')"
	echo "$connUser ~~~~~~~~" >>$UPDATELOG
        connPwdDec=$(java -cp /opt/cisco/ss/adminshell/lib/LCMDecryptor.jar:/opt/cisco/ss/adminshell/lib/* com.cisco.ca.ss.lcmutil.EncryptionUtil $connPwdEnc)

	CONNAUTH="-H userid:$connUser -H password:$connPwdDec -f "
        CRED="$CURLFLAGS $CONNAUTH"	
	
        printf "\n$PREFIX: Getting File details from the server\n" >> $UPDATELOG
        #Get the filename
        OUTPUTFILE=$2
	url=$1
	POSTDATA=""
	PROGRESS=""
	echo "-==$url>>>>>" >>$UPDATELOG
	if test -z "$url"
	then
		printf "\n$PREFIX: Empty URL error\n" >> $UPDATELOG
	    	TME=`$DATE`
		printf "[${TME}] $PREFIX: Error in downloading file. Try Again..\n" >> $UPDATELOG
		printf "$CODE_NFOUND:Package not found\n"
		 
		 var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
		var2="$(echo -e "${var2}" | tr -d '[:space:]')"
		/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_NFOUND', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
				
		CLEANUP
			
	fi


	if test -n "$POSTDATA"
	then
		POSTDATA=" --data $POSTDATA"
		PROGRESS=" -s"		
	fi

        #remove local cpy if any
        $RM -f $OUTPUTFILE
	echo "$OUTPUTFILE~~~~~~~~~~~~~~~~~~ " >>$UPDATELOG 
        $CURL $CRED $CERT -o $OUTPUTFILE $url $POSTDATA $PROGRESS >> $UPDATELOG 2>&1
        retval=$?
        if [ $retval = 56 ] #the proxy need NTLM authentication
        then
                CURLFLAGS="$CURLFLAGS --proxy-ntlm "
                $CURL $CERD $CERT -o $OUTPUTFILE $url $POSTDATA  $PROGRESS >> $UPDATELOG 2>&1
                retval=$?
        fi
        if [[ $retval = 60 ]];then #that failed again! need --insecure
                CERT="--insecure "
                $CURL $CERD $CERT -o $OUTPUTFILE $url $POSTDATA  $PROGRESS >> $UPDATELOG 2>&1
		retval=$?
        fi
	if [[ $retval != 0 ]];then
		TME=`$DATE`
		printf "[${TME}] $PREFIX: Error in downloading file. Try Again..\n" >> $UPDATELOG
		if [[ $retval = 52 ]];then
			printf "$ERROR_DOWNLOAD:Error in downloading package\n"
			 
			  var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
			var2="$(echo -e "${var2}" | tr -d '[:space:]')"
			 /bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$ERROR_DOWNLOAD', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
						 
		else
			printf "$CODE_NAUTH:Authentication failed\n"
			 
			  var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
			var2="$(echo -e "${var2}" | tr -d '[:space:]')"
			/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_NAUTH', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
						
		fi
		CLEANUP
	fi
}

#######################################
####   MAIN BODY    ###################
#######################################

##extracting arguments to INSTALL sript
ARGS_TO_INSTALL=($*)

url=$1
imagefile=$2

downloadLoc=/opt/LCM/tmp/downloads/

if [ ! -d "$downloadLoc" ]; then
  mkdir -p $downloadLoc
fi

imageLoc=$downloadLoc$imagefile

echo "$imagefile ==========" >>$UPDATELOG
TME=`$DATE`
echo "[${TME}] Starting download operation" >>$UPDATELOG
if test -n "$url"
then
        #printf "\n *** Getting File details from the server\n\n"
        #Get the filename
        OUTPUTFILE="$imagefile"
	echo " $OUTPUTFILE ++++++++++++" >> $UPDATELOG
	
	perform_http "$url" "$imageLoc"
	
	/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "UPDATE ORDEREDLIST SET status='Downloaded' WHERE PACKAGELOCATION='$imagefile';"
	CLEANUP
fi
