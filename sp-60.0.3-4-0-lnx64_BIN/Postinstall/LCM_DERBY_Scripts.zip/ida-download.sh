#!/bin/bash
#trap exit INT
trap exit 2 3 15
trap "" 1
################
#Copyright (C) 2009 ArcanaNetworks, Inc. No part of this file may be reproduced, stored in a retrieval system, or transmitted, in any form or by any means, electronic, mechanical, photocopying, recording or otherwise without the prior permission of the publisher.Any rights not expressly granted herein are reserved.
###############

export PATH="/opt/java/jre/bin:$PATH"

NTLMAPROXY=ntlmaproxy
NTLMA_PROXY=127.0.0.1
NTLMA_PORT=5865

SED=/bin/sed
DATE=`date`
GREP=/bin/grep
SORT=/bin/sort
CUT=/bin/cut
ECHO=/bin/echo
AWK=/bin/awk
BINDIR=/usr/bin
CURL=$BINDIR/curl
CAT=/bin/cat 
TAR=/bin/tar
RM=/bin/rm
DF=/bin/df
MD5SUM=/usr/bin/md5sum
TR=/usr/bin/tr
MASTERFILE=SNOOSC-RELINFO
PROXYINFO_FILE=/etc/scproxyinfo
CONFIGUREPROXY=$BINDIR/configureproxy
DATE=/bin/date
DU=/usr/bin/du
MV=/bin/mv
WGET=/usr/bin/wget

CERT=""
UPDATELOG=/opt/LCM/logs/install
TEE=/usr/bin/tee
PREFIX="IDA-DOWNLOAD"
AGENTPROP=/opt/cisco/ss/adminshell/properties/adminshell.properties

CODE_SUCCESS="2008"
CODE_NAUTH="2009"
CODE_NFOUND="2010"
CODE_REGISTER="2011"
CODE_DENIED="2012"
CODE_ERROR="2013"
ERROR_DOWNLOAD="2014"
UNRECO_ERROR="2015"
EXECP_ERROR="2016"
UNKNOWN_ERROR="2017"
CHECKSUM_ERROR="2018"
FILE_ERROR="2019"
REGISTERURL_ERROR="2020"
DBFILE_ERROR="2021"

#getting proxy information 
if [ -f $PROXYINFO_FILE ];then
	. $PROXYINFO_FILE
fi

if [ -n "$proxyname" ]
then
	CURLFLAGS="--proxy $proxyname:$proxyport "
fi

if [ -n "$proxyuser" ]
then
	PROXY_AUTH="--proxy-user $proxyuser:$proxypassword "
        CURLFLAGS="$CURLFLAGS $PROXY_AUTH "
else
         PROXY_AUTH="--proxy-user dummy:dummy"
         CURLFLAGS="$CURLFLAGS $PROXY_AUTH "	 
fi
	 
if [ "$socks" = "yes" ]	 
then	 
         CURLFLAGS="$CURLFLAGS --socks5 $proxyname:$proxyport"	

fi

CLEANUP()
{
	printf "\n$PREFIX: Removing temporary files...\n" >> $UPDATELOG
	$RM -rf temp_out1
	exit 0
}

fetch_download_url()
{

	connUser=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/registerInfo;create=true;user=app;password=password';" "select GENERIC_USER_ID from REGISTER_INFO;")
	echo "user : $connUser"
	connPwdEnc=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/registerInfo;create=true;user=app;password=password';" "select GENERIC_PASSWORD from REGISTER_INFO;")
	connPwdDec=$(java -cp /opt/cisco/ss/adminshell/lib/LCMDecryptor.jar:/opt/cisco/ss/adminshell/lib/* com.cisco.ca.ss.lcmutil.EncryptionUtil $connPwdEnc)

	printf "\n$PREFIX: Getting File details from the server\n" >> $UPDATELOG
        #Get the filename
        OUTPUTFILE=$2
        url=$1
	if test -z "$url"
        then
                printf "\n$PREFIX: Empty URL error\n" >> $UPDATELOG
                TME=`$DATE`
                printf "[${TME}] $PREFIX: Error in downloading file. Try Again..\n" >> $UPDATELOG
                printf "$CODE_NFOUND:Package not found\n"
                
				var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_NFOUND', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
                
                CLEANUP

        fi

	CONNAUTH="-H userid:$connUser -H password:$connPwdDec -f "
	CRED="$CURLFLAGS $CONNAUTH"	


	$CURL $CRED $CERT $url -o $OUTPUTFILE  >> $UPDATELOG 2>&1
	 retval=$?

        if [ $retval = 56 ] #the proxy need NTLM authentication
        then
                CRED="$CRED --proxy-ntlm "
                $CURL $CRED $CERT -o $OUTPUTFILE $url $PROGRESS >> $UPDATELOG 2>&1
                retval=$?
        fi
        if [[ $retval = 60 ]];then #that failed again! need --insecure
                CERT="--insecure "
                $CURL $CRED $CERT -o $OUTPUTFILE $url $PROGRESS >> $UPDATELOG 2>&1
                retval=$?
        fi
        if [[ $retval != 0 ]];then
                TME=`$DATE`
                printf "[${TME}] $PREFIX: Error in downloading file. Try Again..\n" >> $UPDATELOG
                if [[ $retval = 52 ]];then
                        printf "$ERROR_DOWNLOAD:Error in downloading package\n"
                
						 var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
						 /bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$ERROR_DOWNLOAD', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
                
                else
                        printf "$CODE_NAUTH:Authentication failed\n"
                
				 var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
						/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_NAUTH', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
                fi
                CLEANUP
        fi
}

url_encode()
{
INSTR=$1
POSTDATA=""
if test -z "$INSTR"
then
	return
fi
	subs="s/%/%25/g s/\\\$/%24/g s/&/%26/g s/+/%2B/g s/,/%2C/g s/\//%2F/g s/:/%3A/g s/;/%3B/g s/=/%3D/g s/?/%3F/g s/@/%40/g s/</%3C/g s/>/%3E/g s/#/%23/g  s/{/%7B/g s/}/%7D/g  s/\\\\/%5C/g s/\^/%5E/g s/\~/%7E/g s/\[/%5B/g s/\]/%5D/g s/\`/%60/g s/\"/%22/g"

for i in $subs
do
        TINSTR=`echo $INSTR | $SED $i`
        INSTR=$TINSTR
        #echo $INSTR
        #echo ""
done

TINSTR=`echo $INSTR |  $SED s/\|/%7C/g`
INSTR=$TINSTR
#echo $INSTR
TINSTR=`echo $INSTR |  $SED 's/ /%20/g'`

POSTDATA="inputXML=$TINSTR"
#echo $POSTDATA
	
}

# To perform curl GET /POST
#args  url outputfile data(if any)
perform_http()
{
        printf "\n$PREFIX: Getting File details from the server\n" >> $UPDATELOG
        #Get the filename
        OUTPUTFILE=$2
	url=$1
	#data=$3
	POSTDATA=""
	PROGRESS=""
	if test -z "$url"
	then
		printf "\n$PREFIX: Empty URL error\n" >> $UPDATELOG
	    	TME=`$DATE`
		printf "[${TME}] $PREFIX: Error in downloading file. Try Again..\n" >> $UPDATELOG
		printf "$CODE_NFOUND:Package not found\n"
		
		var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
		/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_NFOUND', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
        
		CLEANUP
			
	fi

	#url_encode "$data"

	if test -n "$POSTDATA"
	then
		POSTDATA=" --data $POSTDATA"
		PROGRESS=" -s"		
	fi

        #remove local cpy if any
        $RM -f $OUTPUTFILE
        $CURL $DOWNCURLFLAGS $CERT -o $OUTPUTFILE $url $POSTDATA $PROGRESS >> $UPDATELOG 2>&1
        retval=$?
        if [ $retval = 56 ] #the proxy need NTLM authentication
        then
                DOWNCURLFLAGS="$DOWNCURLFLAGS --proxy-ntlm "
                $CURL $DOWNCURLFLAGS $CERT -o $OUTPUTFILE $url $POSTDATA  $PROGRESS >> $UPDATELOG 2>&1
                retval=$?
        fi
        if [[ $retval = 60 ]];then #that failed again! need --insecure
                CERT="--insecure "
                $CURL $DOWNCURLFLAGS $CERT -o $OUTPUTFILE $url $POSTDATA  $PROGRESS >> $UPDATELOG 2>&1
		retval=$?
        fi
	if [[ $retval != 0 ]];then
		TME=`$DATE`
		printf "[${TME}] $PREFIX: Error in downloading file. Try Again..\n" >> $UPDATELOG
		if [[ $retval = 52 ]];then
			printf "$ERROR_DOWNLOAD:Error in downloading package\n"
		
			 var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
			 /bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$ERROR_DOWNLOAD', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
        
		else
			printf "$CODE_NAUTH:Authentication failed\n"
			  
			   var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
			 /bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_NAUTH', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
		fi
		CLEANUP
	fi
}

#######################################
####   MAIN BODY    ###################
#######################################

##extracting arguments to INSTALL sript
ARGS_TO_INSTALL=($*)

imagename=$1
username=$2
if [ -e /opt/LCM/lcmsec ]
then
	password=`cat /opt/LCM/lcmsec`
	rm -rf /opt/LCM/lcmsec
else
	password=$3
fi

AUTH="--user $username:$password  -f "
DOWNCURLFLAGS="$CURLFLAGS $AUTH"

PROD_LOCATOR=`cat $AGENTPROP | grep "^REGISTER_URL=https://tools.cisco.com/cspcEntitlement"`
STAGE_LOCATOR=`cat $AGENTPROP | grep "^REGISTER_URL=LOCAL"`
if test "$STAGE_LOCATOR" != ""
then
	imagefile=`echo $imagename | cut -d: -f1`
	imagenum=`echo $imagename | cut -d: -f2`
	url="https://upload.cisco.com/cgi-bin/swc/fileexg/main.cgi/${imagefile}?menu=download2&file=${imagenum}&encrypted_type=0&agree=I%20Agree&CONTYPES=SmartServicesLCM"
elif test "$PROD_LOCATOR" != ""
then
	url=""
else
        printf "\n$PREFIX: Invalid Register URL\n" >> $UPDATELOG
        TME=`$DATE`
        printf "[${TME}] $PREFIX: Invalid Register URL\n" >> $UPDATELOG
        printf "$REGISTERURL_ERROR:Invalid Register URL\n"
        
		var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
		/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$REGISTERURL_ERROR', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
       
                CLEANUP
fi

TME=`$DATE`
echo "[${TME}] Starting download operation" >>$UPDATELOG
if test -n "$url"
then
        #printf "\n *** Getting File details from the server\n\n"
        #Get the filename
        OUTPUTFILE="$imagefile"

	for i in {1..5}
	do
		sleep 2

	        #remove local cpy if any
	        $RM -f $OUTPUTFILE
	        $CURL $DOWNCURLFLAGS $CERT -o $OUTPUTFILE $url >> $UPDATELOG 2>&1
	        retval=$?
	        if [ $retval == 56 ] #the proxy need NTLM authentication
	        then
	                DOWNCURLFLAGS="$DOWNCURLFLAGS --proxy-ntlm "
	                $CURL $DOWNCURLFLAGS $CERT -o $OUTPUTFILE $url >> $UPDATELOG 2>&1
	                retval=$?
	        fi
	        if [[ $retval != 0 ]];then #that failed again! need --insecure
	                CERT="--insecure "
	                $CURL $DOWNCURLFLAGS $CERT -o $OUTPUTFILE $url >> $UPDATELOG 2>&1
                if [[ $? != 0 ]];then
                        printf "\n$FILE_ERROR :Error in getting installation file. Try Again..\n" >>$UPDATELOG
			
			var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
			/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$FILE_ERROR', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
	        
	                        exit 1
	                fi
	        fi

		output=`file $OUTPUTFILE | grep "Zip archive data"`
		if test -n "$output"
		then
			break
		fi
	done

	output=`file $OUTPUTFILE | grep "Zip archive data"`
	if test -z "$output"
	then
		printf "\nUnrecognized file type ("$output"). Downloaded file is corrupted.\n" >> $UPDATELOG
		printf "$UNRECO_ERROR:Unrecognized file type\n"
		if [[ $imagename != 'DUMMY-FILE' ]]
		then 
		
		var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
		/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$UNRECO_ERROR', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
        
        fi
		CLEANUP
	fi
else

#Cisco SW Center

#	REQUEST LEVEL1

	PROD_LOCATOR=`cat $AGENTPROP | grep "^REGISTER_URL=https://tools.cisco.com/cspcEntitlement"`
	STAGE_LOCATOR=`cat $AGENTPROP | grep "^REGISTER_URL=https://tools-stage.cisco.com/cspcEntitlement"`
	if test "$PROD_LOCATOR" != ""
	then
		
		EncPwd=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/servInfo;create=true;user=app;password=password';" "select PARTNER_PASSWORD from SERV_INFO;")
		
		if test -z $EncPwd
		then
		        printf "\n Enabling server connection in progress \n" >> $UPDATELOG
			EncPwd=$(java -cp /opt/cisco/ss/adminshell/lib/LCMEncryptor.jar:/opt/cisco/ss/adminshell/lib/* com.cisco.ca.ss.lcmutil.EncryptionUtil $password)
		fi
		
		applianceID=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/registerInfo;create=true;user=app;password=password';" "select CONN_APPLIANCE_ID from REGISTER_INFO;")
		
		serverIP=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/registerInfo;create=true;user=app;password=password';" "select CONN_LB_URL from REGISTER_INFO;")
		serviceURL="snlcm/lcm/service/downloadLocation"
		printf "$serverIP" >> $UPDATELOG
		if [[ $serverIP == *"72.163.7.113"* ]]
		then
                	serverIP="https://concsoweb-prd.cisco.com/"
		fi
		URL_L1="$serverIP$serviceURL/$applianceID/$imagename/$username/$EncPwd"
		printf "$URL_L1" >> $UPDATELOG
		URL_REGISTER="http://tools.cisco.com/legal/k9/controller/do/k9Check.x?eind=Y"
	elif test "$STAGE_LOCATOR" != ""
	then
		URL_L1="https://www-stage.cisco.com/cgi-bin/front.x/ida/locator/locator.pl"
                URL_REGISTER="http://tools-stage-was6.cisco.com/YS2RPF/RPF_SERVICES/K9FTPUpdateServlet?USER_ID=$username&FLAG=K9_ACCESS_FLAG&VALUE=A"
	else
		printf "\n$PREFIX: Invalid Register URL\n" >> $UPDATELOG
                TME=`$DATE`
                printf "[${TME}] $PREFIX: Invalid Register URL\n" >> $UPDATELOG
                printf "$REGISTERURL_ERROR:Invalid Register URL\n"
                if [[ $imagename != 'DUMMY-FILE' ]]
				then
        
				var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$REGISTERURL_ERROR', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
                fi
                CLEANUP		
	fi

	printf "\n$PREFIX: Sending request for the list of available updates...\n" >> $UPDATELOG
	fetch_download_url "$URL_L1" "temp_out1"
	echo `$CAT temp_out1` >> $UPDATELOG
	RES_LEVEL1=`$CAT temp_out1`
	if [[ $imagename == 'DUMMY-FILE' ]]
	then
		if [[ $RES_LEVEL1 = 'Authentication Succeeded' ]]
	        then
			printf "\nUnrecognized file type. Downloaded file is corrupted.\n" >> $UPDATELOG
	                printf "$UNRECO_ERROR:Unrecognized file type\n"
			CLEANUP
	        else
			printf "$CODE_NAUTH:Authentication failed\n"
			CLEANUP
        	fi
	fi
	EXCEPTION=`echo "$RES_LEVEL1" | $AWK 'BEGIN {RS="</exception>"}  /.*<exception>.*/ {print $0}'`
	if test -n "$EXCEPTION"
	then
		printf "Exception response received\n" >> $UPDATELOG
		echo "$EXCEPTION" | $GREP "<message>" | $SED 's/<message>//g' |  $SED 's/<\/message>//g' >> $UPDATELOG
                echo "$RES_LEVEL1" | $GREP "<message>" | $SED 's/<message>//g' |  $SED 's/<\/message>//g' >> $UPDATELOG
                ERRCODE=`echo "$RES_LEVEL1" | $GREP "<status>" | $SED 's/<status>//g' | $SED 's/<\/status>//g'`
                if test -n $ERRCODE; then
                        printf "\n$PREFIX: Status Code : %s\n" $ERRCODE >> $UPDATELOG
			ERRCODE=`echo ${ERRCODE//[[:blank:]]/}`
                        if test "$ERRCODE" = "006"
                        then
                                printf "$CODE_DENIED:IP check failed\n"
                                if [[ $imagename != 'DUMMY-FILE' ]]
								then
		
				var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
		
					   /bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_DENIED', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
		                fi
			elif test "$ERRCODE" = "1001"
			then
				printf "\n$PREFIX: Register at %s\n" "$URL_REGISTER" >> $UPDATELOG
				printf "$CODE_REGISTER:$URL_REGISTER\n"
				if [[ $imagename != 'DUMMY-FILE' ]]
		then
		
				var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
	    
						 /bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_REGISTER', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
	        	        fi
				CLEANUP
                        else
                                printf "$EXECP_ERROR:Exception result received\n"
                                if [[ $imagename != 'DUMMY-FILE' ]]
		then
		
				var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
		
					    /bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$EXECP_ERROR', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
                        fi
                fi
                fi
		CLEANUP
	fi
		
	AVAILABLE_VERSIONS=`echo "$RES_LEVEL1"| $AWK 'BEGIN  {RS="</[ ]*image[ ]*>"} /<[ ]*image[ ]*>.*/ {print $0} '|$GREP "<[ ]*property[ ]* name=\"[ ]*imageName[ ]*\"" |$SED 's%<[ ]*property[ ]*name[ ]*=[ ]*\"[ ]*imageName[ ]*\"[ ]* value[ ]*=[ ]*\"\(.*\)\"/>%\1%g'`
	printf "Available versions  $AVAILABLE_VERSIONS\n" >> $UPDATELOG
	
	
	if test -z "$AVAILABLE_VERSIONS"
	then
		printf "No updates are available\n" >> $UPDATELOG
		printf "$CODE_NFOUND:Package not found\n"
		if [[ $imagename != 'DUMMY-FILE' ]]
		then
		
		var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
        
				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_NFOUND', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
                fi
		CLEANUP
	fi
	printf "\n$PREFIX: Downloading package with imageName $imagename ...\n" >> $UPDATELOG
		
	#LEVEL2
	
	DOWNLOAD_DATA=`echo "$RES_LEVEL1" |$AWK  'BEGIN  {RS="[ ]*</[ ]*image[ ]*>"} /<[ ]*image[ ]*>.*'$UPDATE_TYPE'.*'$UPDATE_PLATFORM'.*/ {print $0} '|$AWK 'BEGIN {RS="[ ]*<[ ]*image[ ]*>[ ]*"} /.*property[ ]* name[ ]*=[ ]*"[ ]*imageName[ ]*"[ ]* value[ ]*=[ ]*"[ ]*'$imagename'[ ]*"/ {print $0 }'`
	CHECKSUM_DATA=`echo "$RES_LEVEL1" |$AWK  'BEGIN  {RS="[ ]*</[ ]*image[ ]*>"} /<[ ]*image[ ]*>.*'$UPDATE_TYPE'.*'$UPDATE_PLATFORM'.*/ {print $0} '|$AWK 'BEGIN {RS="[ ]*<[ ]*image[ ]*>[ ]*"} /.*property[ ]* name[ ]*=[ ]*"[ ]*imageName[ ]*"[ ]* value[ ]*=[ ]*"[ ]*'$imagename'[ ]*"/ {print $0 }'`
	##### Command changed to handle new response as Locator functionality moved to Manager #######

	CHECKSUM=`echo "$CHECKSUM_DATA" | sed -e "s/.*checksum//;s/md5.*//" | sed -e "s/.*value=//;s/type.*//" | sed "s/\"//g"`	

	##### Command changed to handle new response as Locator functionality moved to Manager #######
	URL_L2=`echo "$DOWNLOAD_DATA" | $GREP -o -E 'http://dl[^ ]+' |$SED 's/".*//'`
	URL_L2=$(echo $URL_L2 | sed "s/http/https/g")
	printf "URL_L1: \"$URL_L1\"\n" >> $UPDATELOG
	printf "URL_L2: \"$URL_L2\"\n" >> $UPDATELOG
	if test "${URL_L2// /}" = "${URL_L1// /}"
	then
		printf "\n$PREFIX: Register at %s\n" "$URL_REGISTER" >> $UPDATELOG
		printf "$CODE_REGISTER:%s\n" $URL_REGISTER
		if [[ $imagename != 'DUMMY-FILE' ]]
		then
		
		var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
        
				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CODE_REGISTER', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
                fi
		CLEANUP
	fi

	if [[ "$URL_L2" == *dl-stage.cisco.com* ]]
	then
		# Workaround for temp IDA Nprod issue
		$RM -f 403.html
		$WGET $URL_L2 >> $UPDATELOG 2>&1
		if [ -f 403.html ]
		then
			URL_L2=${URL_L2/dl-stage.cisco.com/dl-lt.cisco.com}
			printf "Modified URL_L2: \"$URL_L2\"\n" >> $UPDATELOG
			$RM -f 403.html
		fi
	fi

	printf "Downloading file $URL_L2\n" >> $UPDATELOG
	perform_http "$URL_L2" "$imagename"
fi
	
	TME=`$DATE`
	printf "[${TME}] Download completed\n" >> $UPDATELOG
    	SZE=`$DU -k $OUTPUTFILE`
    	printf "File size [in KB] : $SZE\n" >> $UPDATELOG


	if test -n "$CHECKSUM"
	then
		TME=`$DATE`
		printf "[${TME}] Validating checksum of the downloaded file]\n" >> $UPDATELOG
		LOCAL_CHKSUM=`$MD5SUM $OUTPUTFILE| $AWK ' {  print $1 }'`
		LOCAL_CHKSUM=`echo $LOCAL_CHKSUM | $TR [:lower:] [:upper:]`
		CHECKSUM=`echo $CHECKSUM | $TR [:lower:] [:upper:]`
		if test "$LOCAL_CHKSUM" != "$CHECKSUM"
		then
			printf "\n$PREFIX: Checksum error. Downloaded file is corrupted. ("$LOCAL_CHKSUM", "$CHECKSUM")\n" >> $UPDATELOG
			printf "$CHECKSUM_ERROR:Checksum error\n"
			if [[ $imagename != 'DUMMY-FILE' ]]
		then
		
			var2=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "select AVAILABLE_VERSION from UPDATES where PACKAGE_STATUS='Downloading';")
        
				
				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET MESSAGE_ID='$CHECKSUM_ERROR', PACKAGE_STATUS='Download-failed' WHERE AVAILABLE_VERSION='$var2';"
                fi
	        	CLEANUP
		else
			TME=`$DATE`
			printf "[${TME}] Checksum validation is success.\n" >> $UPDATELOG
		fi
	fi
	printf "$CODE_SUCCESS:Package download successful\n"
	CLEANUP

###
