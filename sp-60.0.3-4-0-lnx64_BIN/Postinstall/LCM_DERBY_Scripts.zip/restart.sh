#!/bin/bash

service adminshell restart >/dev/null 2>&1 &
popd 1>/dev/null 2>&1

exit 0
