#!/bin/bash

timestamp=`date +%s`

packageName=$1

packageName="$(echo -e "${packageName}" | tr -d '[:space:]')"

dir=$(pwd)
echo $dir

packageLoc=/opt/LCM/tmp/
cd /opt/LCM/tmp/downloads

patch=$packageLoc$packageName-package.zip

zip -r $patch *.zip

cd $dir

rm -rf /opt/LCM/tmp/downloads/

echo "Package Zip file created"


/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "UPDATE UPDATES SET PACKAGE_STATUS='Downloaded', DOWNLOAD_END='$timestamp' , DOWNLOAD_PERCENTAGE='100', PACKAGE_LOCATION='$patch' WHERE AVAILABLE_VERSION='$packageName';"

echo "Updates db updated with Download end date"

exit 0
