#!/bin/bash

DB_FILES="/opt/LCM/info"
APPLY_LOGS="/opt/LCM/logs/apply"

echo "Inside status_update script" >> $APPLY_LOGS

packageName=$1
packageName="$(echo -e "${packageName}" | tr -d '[:space:]')"

status=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select status from orderedList where packageName='$packageName';")
status="$(echo -e "${status}" | tr -d '[:space:]')"
echo "Status of package : $status" >> $APPLY_LOGS


timestamp=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select timestamp from orderedList where packageName='$packageName';")
echo "Timestamp : $timestamp" >> $APPLY_LOGS

echo "Updating updates db" >> $APPLY_LOGS
applyend=$(date +%s)

/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "update updates set package_status='$status', APPLY_END='$applyend' where AVAILABLE_VERSION='$packageName';"

echo "Deleting entry from orderedList db" >> $APPLY_LOGS

/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "delete from orderedList where packageName='$packageName';"


/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "delete from orderedList;"
rm -rf /opt/LCM/tmp/*lnx64.zip
sed -i.bak '/status_update.sh/d' /opt/cisco/ss/adminshell/bin/shellserver
exit 0