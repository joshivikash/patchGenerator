#!/bin/bash

#===============================================================
#Initialization of variables
#===============================================================
APPLY_LOGS="/opt/LCM/logs/apply"
DB_FILES="/opt/LCM/info"

echo "Inside Apply script" >> $APPLY_LOGS
echo "Package Name : $1" >> $APPLY_LOGS
echo "Timestamp : $2" >> $APPLY_LOGS

count=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select count(orderId) from ORDEREDLIST where timestamp='$2';")

count="$(echo -e "${count}" | tr -d '[:space:]')"

echo "Count : $count" >> $APPLY_LOGS
append="-package.zip"
full_path=$1$append
unzip -o $full_path -d /opt/LCM/tmp
#Removing restart of adminshell from postinstall
cwd=`pwd`
zipinfo -1 $full_path > /opt/cisco/ss/adminshell/tmp/newlist
mkdir /opt/cisco/ss/adminshell/tmp/newpatch
while IFS='' read -r line || [[ -n "$line" ]]; do
        unzip -o /opt/LCM/tmp/$line -d /opt/cisco/ss/adminshell/tmp/newpatch
        IFS='z' read -a list <<< "$line"
        pname="${list[0]%?}"
        if [ -d /opt/cisco/ss/adminshell/tmp/newpatch/$pname/Postinstall ]
        then
                sed -i.bak '/nohup/d' /opt/cisco/ss/adminshell/tmp/newpatch/$pname/Postinstall/install.sh
                sed -i.bak '/pushd/d' /opt/cisco/ss/adminshell/tmp/newpatch/$pname/Postinstall/install.sh
                sed -i.bak '/popd/d' /opt/cisco/ss/adminshell/tmp/newpatch/$pname/Postinstall/install.sh
                rm -rf /opt/cisco/ss/adminshell/tmp/newpatch/$pname/Postinstall/install.sh.bak
                rm -rf /opt/LCM/tmp/$line
                cd /opt/cisco/ss/adminshell/tmp/newpatch
                zip -r /opt/LCM/tmp/$line $pname
        fi

        rm -rf $pname
done < /opt/cisco/ss/adminshell/tmp/newlist
cd $cwd
rm -rf /opt/cisco/ss/adminshell/tmp/newpatch

j=`expr $count - 1`

i=0
for (( pkg=1 ; pkg<=$count ; pkg++ ))
do
	echo "Order Id : $i" >> $APPLY_LOGS
	echo "Timestamp : $2" >> $APPLY_LOGS
	pkgname=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select packagezipName from orderedList where timestamp='$2' and orderId='$i';")
	type=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select packageName from orderedList where timestamp='$2' and orderId='$i';")
	echo "Package Name : $pkgname" >> $APPLY_LOGS
	echo "Package Type : $type" >> $APPLY_LOGS
	if [[ ${type:0:2} = "sp" ]]
	then
		pkgType="SP"
	else
		pkgType="JeOS"
	fi

	echo "Package Name : $pkgname" >> $APPLY_LOGS
	echo "Package Type : $pkgType" >> $APPLY_LOGS

	patch="$pkgname"
	patch="$(echo -e "${patch}" | tr -d '[:space:]')"
	echo "Patch Name : $patch" >> $APPLY_LOGS
	
	pkgstatus=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select status from orderedList where timestamp='$2' and packagezipName='$patch';")
	if [ "$pkgstatus" == 'Applied' ]
	then
		echo "Order ID : $i" >> $APPLY_LOGS
		i=`expr $i + 1`
		echo "Order Id after increment : $i" >> $APPLY_LOGS
	else 
	
		/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "update orderedList set STATUS='Apply-in-Progress' where packagezipName='$patch' and timestamp='$2';"
		echo "Package Type : $pkgType" >> $APPLY_LOGS
		echo "Patch Name : $patch" >> $APPLY_LOGS
		/opt/LCM/bin/lcmagent-apply.tcl "$pkgType" "$patch"
		exitStatus=$?
		if [[ "$exitStatus" == "1" ]]
		then 
			exit 1		
		fi
		flag=true
		while [ "$flag" == 'true' ]
		do
	
			status=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select status from orderedList where packagezipName='$patch' and timestamp='$2';")
			status="$(echo -e "${status}" | tr -d '[:space:]')"
			if [ "$status" == 'Applied' ]
			then
	
				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "update updates set package_status='$status' where AVAILABLE_VERSION='$type';"
				echo "inside" >> $APPLY_LOGS
				flag=false
				sleep 60
				i=`expr $i + 1`
				echo "Order Id : $i" >>$APPLY_LOGS
			elif [ "$status" == 'Apply-failed' ]
			then
	
				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "update updates set package_status='Apply-failed' where AVAILABLE_VERSION='$type';"
	
				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "delete from orderedList;"
				exit 1
			fi
		done
	fi
done
exit 0
