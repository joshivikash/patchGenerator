#!/bin/bash

export PATH=/opt/java/jre/bin:$PATH

#===============================================================
#Initialization of variables
#===============================================================
APPLY_LOGS="/opt/LCM/logs/apply"
DB_FILES="/opt/LCM/info"

#Delete entry from shellserver
sed -i.bak '/Resume.sh/d' /opt/cisco/ss/adminshell/bin/shellserver

#Fetching package Details

timestamp=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select timestamp from orderedList where status='next';")
timestamp="$(echo -e "${timestamp}" | tr -d '[:space:]')"
orderId=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select orderId from orderedList where status='next';")
count=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select count(orderId) from orderedList where timestamp='$timestamp';")
count="$(echo -e "${count}" | tr -d '[:space:]')"

orderId="$(echo -e "${orderId}" | tr -d '[:space:]')"
j=`expr $count - 1`

#===============================================================
#Apply of Multiple level patches
#===============================================================
i="$orderId"
for (( pkg=$i ; pkg<$count ; pkg++ ))
do
	echo "Ordered Id : $i" >> $APPLY_LOGS
	echo "Timestamp : $timestamp" >> $APPLY_LOGS
	
	pkgname=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select packagezipName from orderedList where timestamp='$timestamp' and orderId='$i';")
	type=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select packageName from orderedList where timestamp='$timestamp' and orderId='$i';")
	type="$(echo -e "${type}" | tr -d '[:space:]')"
	echo "Package Name : $pkgname" >> $APPLY_LOGS
	echo "Package Type : $type" >> $APPLY_LOGS
	if [[ ${type:0:2} = "sp" ]]
	then
		pkgType="SP"
	else
		pkgType="JeOS"
	fi

	echo "Package Name : $pkgname" >> $APPLY_LOGS
	echo "Package Type : $pkgType" >> $APPLY_LOGS
	patch="$pkgname"
	patch="$(echo -e "${patch}" | tr -d '[:space:]')"
	echo "Patch Name : $patch" >> $APPLY_LOGS

	pkgstatus=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select status from orderedList where timestamp='$timestamp' and packagezipName='$patch';")
	if [ "$pkgstatus" == 'Applied' ]
	then
		echo "$i" >> $APPLY_LOGS
		i=`expr $i + 1`
		echo "Order Id------------$i" >> $APPLY_LOGS
	else 

		/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "update orderedList set STATUS='Apply-in-progress' where packagezipName='$patch' and timestamp='$timestamp';"
		echo " Package Type : $pkgType" >> $APPLY_LOGS
		echo "Patch Name : $patch" >> $APPLY_LOGS
		/opt/LCM/bin/lcmagent-apply.tcl "$pkgType" "$patch"
		
		flag=true
		while [ "$flag" == 'true' ]
		do

			status=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select status from orderedList where packagezipName='$patch' and timestamp='$timestamp';")
			status="$(echo -e "${status}" | tr -d '[:space:]')"
			if [ "$status" == 'Applied' ]
			then
				echo "inside while loop" >> $APPLY_LOGS

				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "update updates set package_status='$status' where AVAILABLE_VERSION='$type';"
				flag=false
				sleep 60
				i=`expr $i + 1`
				echo "Order Id******$i" >> $APPLYLOGS
				echo "Status flag------$flag" >> $APPLYLOGS
			elif [ "$status" == 'Apply-failed' ]
			then

				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "update updates set package_status='Apply-failed' where AVAILABLE_VERSION='$type';"

				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "delete from orderedList;"
				exit 1
			fi
		done
	fi
	#To avoid next patch trigger before going for reboot - One min issue
	sleep 120
done
exit 0
