#!/bin/bash

export PATH=/opt/java/jre/bin:$PATH

pass=$(java -cp /opt/cisco/ss/adminshell/lib/LCMDecryptor.jar:/opt/cisco/ss/adminshell/lib/* com.cisco.ca.ss.lcmutil.EncryptionUtil $1)
echo $pass >> /opt/LCM/lcmsec
exit 0
