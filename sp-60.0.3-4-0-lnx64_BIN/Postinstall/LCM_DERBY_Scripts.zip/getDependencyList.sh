#!/bin/bash

export PATH=/opt/java/jre/bin:$PATH

#===============================================================
#Initialization of variables
#===============================================================
APPLY_LOGS="/opt/LCM/logs/apply"
DB_FILES="/opt/LCM/info"

#===============================================================
#Calling API to get dependencyList
#===============================================================
#Fetching ServiceName
serviceName=`cat $DB_FILES/service.txt`
echo "$serviceName" >> $APPLY_LOGS

#Fetching Currently installed SP and JeOS version

currentSP=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/status;create=true;user=app;password=password';" "select Version from STATUS where NAME='SP';")
currentJeOS=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/status;create=true;user=app;password=password';" "select Version from STATUS where NAME='JeOS';")

echo "$currentSP" >> $APPLY_LOGS
echo "$currentJeOS" >> $APPLY_LOGS
echo "Root Version : $1" >> $APPLY_LOGS

#Fetching Generic userid and Generic Password

gen_userId=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/registerInfo;create=true;user=app;password=password';" "select GENERIC_USER_ID from REGISTER_INFO;")

gen_userId="$(echo -e "${gen_userId}" | tr -d '[:space:]')"


gen_enc_passwd=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/registerInfo;create=true;user=app;password=password';" "select GENERIC_PASSWORD from REGISTER_INFO;")

gen_enc_passwd="$(echo -e "${gen_enc_passwd}" | tr -d '[:space:]')"

#Decrypting password using Decryption method
gen_passwd=$(java -cp /opt/cisco/ss/adminshell/lib/LCMDecryptor.jar:/opt/cisco/ss/adminshell/lib/* com.cisco.ca.ss.lcmutil.EncryptionUtil $gen_enc_passwd)
gen_passwd="$(echo -e "${gen_passwd}" | tr -d '[:space:]')"


CONN_LB_URL=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/registerInfo;create=true;user=app;password=password';" "select CONN_LB_URL from REGISTER_INFO;")

appType=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/systemInfo;create=true;user=app;password=password';" "select APPLIANCE_TYPE from SYSTEM_INFO;")

#Handling host name for stage and prod for curl command
if [[ $CONN_LB_URL == *"72.163.7.113"* ]]
then
        URL="https://concsoweb-prd.cisco.com/"
elif [[ $CONN_LB_URL == *"173.38.37.173"* ]]
then
        URL="https://concsoweb-stg.cisco.com/"
else
        URL=$CONN_LB_URL
fi

#===============================================================
#Fetching and parsing dependency List from manager
#===============================================================
serviceURL="snlcm/lcm/service/dependencyVersion"
dependencyVer="$URL$serviceURL/$1/$currentSP/$currentJeOS/$serviceName/$appType"

URL="$(echo -e "${dependencyVer}" | tr -d '[:space:]')"

curl -i --header "userid:$gen_userId" --header "password:$gen_passwd" -L "$URL" -o "$DB_FILES/update.xml"

#Checking the status of curl command
if ! grep -q "200 OK" "$DB_FILES/update.xml"; then

	/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "update UPDATES SET PACKAGE_STATUS='Apply-failed' WHERE AVAILABLE_VERSION='$rootVersion';"
	echo "Execution of Curl Command failed. Please check update.xml file" >> $APPLY_LOGS
	exit 1
fi

/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/downloadInfo;create=true;user=app;password=password';" "delete from download_info where Tag='$2';"

#Parsing xml data
packageList=($(cat $DB_FILES/update.xml | grep -oP '(?<=packageName>)[^<]+'))

if [ "$packageList" == '' ]
then
        echo "Collector is up-to-date" >> $APPLY_LOGS
        exit 0
fi

j=0
for i in ${!packageList[*]}
do
	echo "${packageList[$i]}" >> $APPLY_LOGS
	IFS='|' read -a list <<< "${packageList[$i]}"
	echo ${list[0]} >> $APPLY_LOGS
	echo ${list[1]} >> $APPLY_LOGS
	echo ${list[2]} >> $APPLY_LOGS
	pkgzip=.zip
	path="/opt/LCM/tmp/"
	pkgzipName=$path${list[0]}$pkgzip
	echo "Package Zip name : $pkgzipName" >> $APPLY_LOGS

	oldCount=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select count(orderId) from orderedList where packageZipName='$pkgzipName';")
        
	echo "order count: $oldCount" >> $APPLY_LOGS

        oldCount="$(echo -e "${oldCount}" | tr -d '[:space:]')"

        if [ "$oldCount" == '0' ]
        then

				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "insert into orderedList values('$i','$2','${list[0]}','${list[1]}','$pkgzipName','');"
        else

				/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "update orderedList set timestamp='$2', orderId='$i', packageName='${list[0]}',packageLocation='${list[1]}' where packageZipName='$pkgzipName';"
        fi


	/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/downloadInfo;create=true;user=app;password=password';" "insert into download_info values('$2','${list[0]}','${list[1]}');"
	j=`expr $j + 1`
done

count=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select count(orderId) from orderedList where timestamp='$2';")

count="$(echo -e "${count}" | tr -d '[:space:]')"

#Check if the insertion of db was successful
if [ "$count" != "$j" ]
then

	/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "update UPDATES SET PACKAGE_STATUS='Apply-failed' WHERE AVAILABLE_VERSION='$rootVersion';"
	echo "Insertion for orderedList failed" >> $APPLY_LOGS
	rm -rf $INSTALL_DIR/orderedList.db
	exit 1
fi

infoCount=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/downloadInfo;create=true;user=app;password=password';" "select count(version) from download_info where Tag='$2';")

infoCount="$(echo -e "${infoCount}" | tr -d '[:space:]')"

if [ "$infoCount" != "$j" ]
then

	/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/updates;create=true;user=app;password=password';" "update UPDATES SET PACKAGE_STATUS='Apply-failed' WHERE AVAILABLE_VERSION='$rootVersion';"
	echo "Insertion for downloadInfo failed" >> $APPLY_LOGS
	rm -rf $INSTALL_DIR/orderedList.db
	exit 1
fi
echo "Finished" >> $APPLY_LOGS
exit 0

