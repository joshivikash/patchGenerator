#!/bin/bash

DB_FILES="/opt/LCM/info"
APPLY_LOGS="/opt/LCM/logs/apply"

echo "Inside update script" >> $APPLY_LOGS

id=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select orderId from orderedList where packagezipName='$1';")

id="$(echo -e "${id}" | tr -d '[:space:]')"

echo "Order Id : $id" >> $APPLY_LOGS

id=`expr $id + 1`

pkgName=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select packageName from orderedList where packagezipName='$1';")

timestamp=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select timestamp from orderedList where packagezipName='$1';")
echo "Package Name : $pkgName" >> $APPLY_LOGS
pkgName="$(echo -e "${pkgName}" | tr -d '[:space:]')"

timestamp="$(echo -e "${timestamp}" | tr -d '[:space:]')"
count=$(/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "select count(orderId) from orderedList where timestamp='$timestamp';")

count="$(echo -e "${count}" | tr -d '[:space:]')"

echo "Count : $count" >> $APPLY_LOGS
if [ "$count" == "$id" ]
then
	echo "Last patch installation finished" >> $APPLY_LOGS
	sed -i.bak '/tail-end-gateway-decoupled/d' /opt/cisco/ss/adminshell/bin/shellserver
	echo "/opt/LCM/bin/status_update.sh $pkgName & >> /opt/LCM/logs/apply" >> /opt/cisco/ss/adminshell/bin/shellserver
	echo "java -cp /opt/cisco/ss/adminshell/properties:/opt/cisco/ss/adminshell/lib/*:/opt/ConcsoTgw/tail-end-gateway-decoupled/lib/* com.cisco.ca.ss.lcm.adminshell.server.Server" >> /opt/cisco/ss/adminshell/bin/shellserver
	exit 0
else
echo "update next package to install" >> $APPLY_LOGS

/bin/sh /opt/LCM/bin/sqliteToDerbyScripts_shell.sh "connect 'jdbc:derby://localhost:1527/opt/LCM/info/orderedList;create=true;user=app;password=password';" "update orderedList set status='next' where orderId='$id';"

sed -i.bak '/tail-end-gateway-decoupled/d' /opt/cisco/ss/adminshell/bin/shellserver

echo "/opt/LCM/bin/Resume.sh & >> $APPLY_LOGS" >> /opt/cisco/ss/adminshell/bin/shellserver

echo "java -cp /opt/cisco/ss/adminshell/properties:/opt/cisco/ss/adminshell/lib/*:/opt/ConcsoTgw/tail-end-gateway-decoupled/lib/* com.cisco.ca.ss.lcm.adminshell.server.Server" >> /opt/cisco/ss/adminshell/bin/shellserver
fi
exit 0
